import React from "react";
import "./login.css";
import { loginUrl } from "./spotify";
import Navbar from "./Navbar";

export default function Login() {
  return (
    <div>
      <Navbar />
    </div>
  );
}
